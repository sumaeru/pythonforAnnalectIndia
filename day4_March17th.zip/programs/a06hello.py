from a06check import (f1,f2)
#from filename import (f1,f2)
#print("hello")
#import random
#print(random.randint(3,9))
print(f1(),f2())

