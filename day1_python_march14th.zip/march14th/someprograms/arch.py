#print('Hello, world!')

#logic
def getSomeWord():
    return "helloworld"

#presentation part
def start():
    message=getSomeWord()
    print(message)

start();