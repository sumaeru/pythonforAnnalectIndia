print("hello world","great world","scrap world")
