x=[2,3];
x.append(4);
print(x[-2])
z=3;
i=x.index(z);
x[i]=55;
print(x) # 2, 55,4



