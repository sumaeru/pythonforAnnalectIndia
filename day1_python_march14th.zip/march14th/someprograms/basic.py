#old stupid dinosaur programmer
def nextNum(numgiven):
    result=numgiven+1
    print("next number is " + int(numgiven))
    


z=nextNum(3);

def isItaArmstrongnumber(number):
    armstrongnumber=False
    return armstrongnumber


print(isItaArmstrongnumber(44))
print(z)




#i=False
#if(i == True):
 #   print("hello" + str(i))
  #  print(123)
#else:
 #   print(456)