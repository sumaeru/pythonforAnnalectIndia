from calc import addNumbers, multiplyNumbers
 
 
# calling functions
addNumbers(2, 5)
multiplyNumbers(5, 4)