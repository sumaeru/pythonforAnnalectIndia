def get3Multiples(factor):  #show you a function which takes list as input
    multiples=[factor*1,factor*2,factor*3];
    return multiples

def start():
    factor=3;
    multiples=get3Multiples(factor)
    print(multiples)


start();