def addNumbers(a, b):
    print("Sum is ", a + b)
 
def subtractNumbers(a, b):
    print("Difference is ", a-b)
 
def multiplyNumbers(a, b):
    print("Product is ", a * b)
 
def divideNumbers(a, b):
    print("Division is ", a / b)
 
def modulusNumbers(a, b):
    print("Remainder is ", a % b)