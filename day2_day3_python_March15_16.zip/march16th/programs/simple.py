num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
total = str(num1 + num2)
print("The sum of two numbers is: " + total)
