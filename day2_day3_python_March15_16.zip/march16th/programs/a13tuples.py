thistuple = ("apple", "banana", "cherry", "apple", "cherry")
print(thistuple)
"""
Tuple items are ordered, unchangeable, and allow duplicate values.

Tuple items are indexed, the first item has index [0], the second item has index [1] etc.
"""