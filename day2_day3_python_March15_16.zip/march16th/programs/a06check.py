def f1():
    return 5

def f2():
    return 7
